<link href="{{ asset('css/bootstrap/bootstrap.css') }}" rel="stylesheet">

<link href="{{ asset('css/jquery/jquery-ui.css') }}" rel="stylesheet">

<link href="{{ asset('css/datatables/dataTables.bootstrap5.css') }}" rel="stylesheet">
<link href="{{ asset('css/datatables/responsive.bootstrap5.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/datatables/buttons.bootstrap5.css') }}" rel="stylesheet">

<link href="{{ asset('css/icons.css') }}" rel="stylesheet">

<link href="{{ asset('css/app.css') }}" rel="stylesheet">
<link href="{{ asset('css/variables.css') }}" rel="stylesheet">
