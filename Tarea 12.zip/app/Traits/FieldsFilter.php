<?php
namespace App\Traits;

trait FieldsFilter
{
	public function filters($entity, $filters)
	{
		var_dump($filters);die;
	}
}